Vue.createApp({
    data() {
        return {
            list: [],
            word: "",
            objects: {},
            objects2: {},
            objects3: {},
            number: 1
        }
    },
    methods: {
        object() {
            this.objects["Messag"] = this.message
            this.objects["Numb"] = this.number
            this.number++
            this.list.push(this.objects)

            this.objects2["Messag"] = this.message.toLowerCase()
            this.objects2["Numb"] = this.number
            this.number++
            this.list.push(this.objects2)
            
            this.objects3["Messag"] = this.message.toUpperCase()
            this.objects3["Numb"] = this.number
            this.number++
            this.list.push(this.objects3)
        }
    }
}).mount("#app")